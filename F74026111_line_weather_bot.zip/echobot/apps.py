from django.apps import AppConfig


class EchobotConfig(AppConfig):
    name = 'echobot'
